

from yoomoney import Authorize



client_id = input("Введите client_id: ")

Authorize(
      client_id=client_id,
      redirect_uri="https://t.me/policeboth_bot",
      scope=["account-info",
             "operation-history",
             "operation-details",
             "incoming-transfers",
             "payment-p2p",
             "payment-shop",
             ]
      )
